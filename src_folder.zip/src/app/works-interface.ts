export interface Works {
    id:number,
    title:string,
    description:string,
    city:string
}