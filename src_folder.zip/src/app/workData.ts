export const workData ={
      "count": 20,
      "WorkFlow": [
        {
          "id": 1,
          "title": "Nahargarh Fort",
          "description": "on the hill",
          "city":"jaipur"
        },
        {
          "id": 2,
          "title": "Pink City",
          "description": "Building is pink",
          "city":"jaipur"      
        },
        {
          "id": 3,
          "title": "TajMahal",
          "description": "Tourism place",
          "city":"agra"       
        },
        {
          "id": 4,
          "title": "Civil",
          "description": "Hospital",
          "city":"ahmadabad"       
        },
        {
          "id": 5,
          "title": "Chauda Rasta",
          "description": "Market",
          "city":"jaipur"      
        },
        {
          "id": 6,
          "title": "terret",
          "description": "erter",
          "city":"ahmadabad"        
        },
        {
          "id": 7,
          "title": "tet",
          "description": "etet",
          "city":"jaipur"       
        },
        {
          "id": 8,
          "title": "TajMahal",
          "description": "Tourism place",
          "city":"agra"       
        },
        {
          "id": 9,
          "title": "Jalmahal",
          "description": "Lake",
          "city":"jaipur"
        },
        {
          "id": 10,
          "title": "Iscon",
          "description": "Temple",
          "city":"ahmadabad"        
        },
        {
          "id": 11,
          "title": "test-1",
          "description": "test-1",
          "city":"agra"
        },
        {
          "id": 12,
          "title": "SG-highwway",
          "description": "National Highway",
          "city":"ahmadabad"      
        },
        {
          "id": 13,
          "title": "Albert hall",
          "description": "Building",
          "city":"jaipur"       
        },
        {
          "id": 14,
          "title": "test",
          "description": "teet",
          "city":"ahmadabad"       
        },
        {
          "id": 15,
          "title": "test22",
          "description": "232",
          "city":"jaipur"      
        },
        {
          "id": 16,
          "title": "terret",
          "description": "erter",
          "city":"ahmadabad"        
        },
        {
          "id": 17,
          "title": "tet",
          "description": "etet",
          "city":"ahmadabad"       
        },
        {
          "id": 18,
          "title": "Fatehpur sikri",
          "description": "MaZar",
          "city":"agra"       
        },
        {
          "id": 19,
          "title": "RedFort",
          "description": " Tourism Fort",
          "city":"agra"
        },
        {
          "id": 20,
          "title": "HawaMahal",
          "description": "Tourism Place",
          "city":"jaipur"        
        }
      ]
    }